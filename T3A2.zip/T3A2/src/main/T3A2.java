package main;

/**** @author Raul*/
public class T3A2 {
    private int horaInicio;
    private int horaFinal;
    private int diaInicio;
    private int diaFinal;
    private int operacion;
    
    public T3A2() {
    }

    public T3A2(int horaInicio, int horaFinal, int diaInicio, int diaFinal, int operacion) {
        this.horaInicio = horaInicio;
        this.horaFinal = horaFinal;
        this.diaInicio = diaInicio;
        this.diaFinal = diaFinal;
        this.operacion = operacion;
    }
    
    

    @Override
    public String toString() {
        return "Entre las " + horaInicio + " hrs del dia " + diaInicio + " y las " + horaFinal + " hrs del dia " + diaFinal + " hay " +operacion+ " horas";
    }

    public int getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(int horaInicio) {
        this.horaInicio = horaInicio;
    }

    public int getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(int horaFinal) {
        this.horaFinal = horaFinal;
    }

    public int getDiaInicio() {
        return diaInicio;
    }

    public void setDiaInicio(int diaInicio) {
        this.diaInicio = diaInicio;
    }

    public int getDiaFinal() {
        return diaFinal;
    }

    public void setDiaFinal(int diaFinal) {
        this.diaFinal = diaFinal;
    }

    public int getOperacion() {
        return operacion;
    }

    public void setOperacion(int operacion) {
        this.operacion = (((diaFinal-diaInicio)-1)*24)+((24-horaInicio)+horaFinal);
    }
    
       
}
