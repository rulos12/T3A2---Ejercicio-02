package main;
import java.util.Scanner;
/**** @author Raul*/
public class Main {

    public static void main(String[] args) {
        calcular();
    }
    public static void calcular(){
        Scanner obj=new Scanner (System.in);
        T3A2 t3a2 = new T3A2();
        
        System.out.println("Ingrese el dia inicio segun sea su numero:"
                +"\n1.-luner"
                +"\n2.-Martes"
                +"\n3.-Miercoles"
                +"\n4.-Jueves"
                +"\n5.-Viernes"
                +"\n6.-Sabado"
                +"\n7.-Domingo");
        int diaInicio = obj.nextInt();
        t3a2.setDiaInicio(diaInicio);
        
        if(diaInicio<=-1 ){
            System.out.println("Por favor ingrese un valor correcto");
            
        }
        else if(diaInicio>=8){
            System.out.println("Por favor ingrese un valor correcto");
        }
        
        else{
            System.out.println("Ingrese la hora de inicio considerando las 24 horas ");
            int horaInicio=obj.nextInt();
            t3a2.setHoraInicio(horaInicio);
            if (horaInicio>=25){
                System.out.println("Por favor ingrese una hora correcta");
            }
            else if(horaInicio<=-1){
                System.out.println("Por favor ingrese una hora correcta");
            }
            else{
            System.out.println("Ingrese el dia final segun se su numero:"
                +"\n1.-luner"
                +"\n2.-Martes"
                +"\n3.-Miercoles"
                +"\n4.-Jueves"
                +"\n5.-Viernes"
                +"\n6.-Sabado"
                +"\n7.-Domingo");
            int diaFinal = obj.nextInt();
            t3a2.setDiaFinal(diaFinal);
            if(diaFinal>=8){
                System.out.println("Por favor ingrese un valor correcto");
            }
            else if(diaFinal<=-1){
                System.out.println("Por favor ingrese un valor correcto");
            }
            if(diaFinal<diaInicio){
            System.out.println("El dia final tiene que ser posterior al dia inicio, por favor ingrese otro dia");
            }
            else{
            System.out.println("Ingrese la hora final considerando las 24 horas ");
            int horaFinal=obj.nextInt();
            t3a2.setHoraFinal(horaFinal);
            if(horaFinal>=25){
                System.out.println("Ingrese un valor correcto");
            }
            else if(horaFinal<=-1){
                System.out.println("Ingrese un valor correcto");
            }
            else{
            t3a2.setOperacion(horaFinal);
            
            System.out.println(t3a2.toString());
            }

            }
            }
        }
        
    }
}
